package adminLogin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import buyFood.DBconnect;
import buyFood.Payment;

public class loginDBUtil {
	
	public static Admin getAdminById(int id) {
	    Admin admin = null;
	    String sql = "SELECT * FROM admin WHERE AdminID = ?";

	    try (Connection con = DBconnect.getConnection();
	         PreparedStatement pstmt = con.prepareStatement(sql)) {

	        pstmt.setInt(1, id);

	        ResultSet rs = pstmt.executeQuery();

	        if (rs.next()) {
	            String name = rs.getString("AdminName");
	            String password = rs.getString("password");

	            admin = new Admin(id, name, password);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return admin;
	}


    // Insert operation
    public static boolean InsertAdmin(String AdminName, String password) {
        boolean isSuccess = false;
        String sql = "INSERT INTO admin (AdminName, password) VALUES (?, ?)";
        
        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
             
            // Set the values for placeholders in the query
            pstmt.setString(1, AdminName);  // Set the first parameter (AdminName)
            pstmt.setString(2, password);    // Set the second parameter (password)

            // Execute the update
            int result = pstmt.executeUpdate();
            isSuccess = (result > 0); // Insert was successful if result is greater than 0

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }

    // Validate operation
    public static List<Admin> validate(String AdminName, String password) {
        List<Admin> adminList = new ArrayList<>();
        String sql = "SELECT * FROM admin WHERE AdminName = ? AND password = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
             
            // Set the values for placeholders in the query
            pstmt.setString(1, AdminName);  // Set AdminName
            pstmt.setString(2, password);    // Set password

            // Execute query
            try (ResultSet result = pstmt.executeQuery()) {
                while (result.next()) { // Use a loop to handle multiple results if necessary
                    int adminID = result.getInt("AdminID");
                    String adminName = result.getString("AdminName");
                    String pass = result.getString("password");

                    Admin a = new Admin(adminID, adminName, pass);
                    adminList.add(a);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return adminList;  // Return the list with admin details or an empty list if no match is found
    }
    
 // Update operation
    public static boolean updateAdmin(int id, String name, String password) {
        boolean isSuccess = false;
        String sql = "UPDATE admin SET AdminName = ?, password = ? WHERE AdminID = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
             
            pstmt.setString(1, name);  
            pstmt.setString(2, password); 
            pstmt.setInt(3, id);        

            // Execute the update
            int result = pstmt.executeUpdate();
            isSuccess = (result > 0); 

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }
    
 // Delete Process
    public static boolean deleteAdmin(int id) {  
        boolean isSuccess = false;

        
        String sql = "DELETE FROM admin WHERE AdminID = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
             
           
            pstmt.setInt(1, id);  
            
          
            int result = pstmt.executeUpdate();
            isSuccess = (result > 0); 
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return isSuccess;
    }


    
 // Data retrieving
    public static List<Admin> getAllAdmins() {
        List<Admin> allAdmins = new ArrayList<>();
        
        String sql = "SELECT * FROM admin";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql);
             ResultSet result = pstmt.executeQuery()) { 

            while (result.next()) {
                int adminID = result.getInt("AdminID");
                String adminName = result.getString("AdminName");
                String pass = result.getString("password");

               
                Admin a = new Admin(adminID, adminName, pass);
                allAdmins.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return allAdmins; 
    }
    
    // Data retrieving
    public static List<Admin> getAllAdmins(int id) {
        List<Admin> allAdmins = new ArrayList<>();
        
        String sql = "SELECT * FROM admin WHERE AdminID = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql);
             ResultSet result = pstmt.executeQuery()) { 

            while (result.next()) {
                int adminID = result.getInt("AdminID");
                String adminName = result.getString("AdminName");
                String pass = result.getString("password");

               
                Admin a = new Admin(adminID, adminName, pass);
                allAdmins.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return allAdmins; 
    }
    public static boolean deleteCustomer(int id) {
        boolean isSuccess = false;
        String sql = "DELETE FROM customer WHERE id=?";

        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = DBconnect.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, id);
            int r = pstmt.executeUpdate();
            isSuccess = r > 0;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return isSuccess;
    }

}
