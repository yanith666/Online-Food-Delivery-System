package adminLogin;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idString = request.getParameter("id");
        String name = request.getParameter("AdminName").trim();
        String password = request.getParameter("password").trim();

        int id = -1;

        try {
            id = Integer.parseInt(idString);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        boolean isTrue = false;

        if (id != -1) {
            isTrue = loginDBUtil.updateAdmin(id, name, password);

            if (isTrue) {
                Admin updatedAdmin = loginDBUtil.getAdminById(id);
                List<Admin> adminDetails = Arrays.asList(updatedAdmin);

                // ✅ Update session attributes
                HttpSession session = request.getSession();
                session.setAttribute("adminDetails", adminDetails);
                session.setAttribute("adminId", updatedAdmin.getAdminID());
                session.setAttribute("adminName", updatedAdmin.getAdminName());
            }
        }

        if (isTrue) {
            RequestDispatcher dis = request.getRequestDispatcher("adminDash.jsp");
            dis.forward(request, response);
        } else {
            RequestDispatcher dis = request.getRequestDispatcher("unsuccess.jsp");
            dis.forward(request, response);
        }
    }
}
