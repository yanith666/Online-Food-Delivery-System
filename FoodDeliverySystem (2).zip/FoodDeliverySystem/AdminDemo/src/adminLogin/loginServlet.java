package adminLogin;

import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/adminLogin")
public class loginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String adminName = request.getParameter("AdminName").trim();
        String password = request.getParameter("password").trim();

        List<Admin> adminDetails = loginDBUtil.validate(adminName, password);

        if (!adminDetails.isEmpty()) {
            Admin admin = adminDetails.get(0);

            // ✅ Set session attributes
            HttpSession session = request.getSession();
            session.setAttribute("adminDetails", adminDetails);
            session.setAttribute("adminName", admin.getAdminName());
            session.setAttribute("adminId", admin.getAdminID());

            RequestDispatcher dis = request.getRequestDispatcher("adminDash.jsp");
            dis.forward(request, response);
        } else {
            request.setAttribute("errorMessage", "Invalid login");
            RequestDispatcher dis = request.getRequestDispatcher("adminLogin.jsp");
            dis.forward(request, response);
        }
    }
}
