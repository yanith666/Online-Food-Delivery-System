package adminLogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnect {

    private static String url = "jdbc:mysql://localhost:3306/food_delivery";  // use your DB name
    private static String user = "root";
    private static String pass = "12345678";

    public static Connection getConnection() throws SQLException {
        Connection con = null;
        try {
            // Load MySQL JDBC driver (optional in modern versions but safe)
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed.");
            e.printStackTrace();
            throw e;
        }
        return con;
    }
}
