package UserLogin;

import java.sql.*;

public class UserDBUtil {

    public static boolean registerUser(String name, String phone, String email, String password) {
        boolean isSuccess = false;

        try (Connection con = DBconnect.getConnection()) {
            String sql = "INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, phone);
            stmt.setString(3, email);
            stmt.setString(4, password); // Consider hashing this in production

            int rows = stmt.executeUpdate();
            isSuccess = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }

    public static User validateLogin(String email, String password) {
        User user = null;

        try (Connection con = DBconnect.getConnection()) {
            String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("password")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

    public static boolean updateUser(int id, String name, String email, String phone) {
        boolean isSuccess = false;

        try (Connection con = DBconnect.getConnection()) {
            String sql = "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.setInt(4, id);

            int rows = stmt.executeUpdate();
            isSuccess = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }

    public static boolean deleteUser(int id) {
        boolean isSuccess = false;

        try (Connection con = DBconnect.getConnection()) {
            String sql = "DELETE FROM users WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);

            int rows = stmt.executeUpdate();
            isSuccess = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }
}