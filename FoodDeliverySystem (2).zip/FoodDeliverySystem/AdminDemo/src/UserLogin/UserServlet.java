package UserLogin;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("register".equals(action)) {
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            boolean success = UserDBUtil.registerUser(name, phone, email, password);
            if (success) {
                response.sendRedirect("login.jsp?success=1");
            } else {
                request.setAttribute("errorMessage", "Registration failed. Email might already be in use.");
                request.getRequestDispatcher("signup.jsp").forward(request, response);
            }

        } else if ("login".equals(action)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            User user = UserDBUtil.validateLogin(email, password);
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                response.sendRedirect("UserFoodItemsServlet"); // Changed from userDash.jsp
            } else {
                request.setAttribute("errorMessage", "Invalid email or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        }
    }
}