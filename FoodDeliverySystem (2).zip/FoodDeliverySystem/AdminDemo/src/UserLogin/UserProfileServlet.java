package UserLogin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UserProfileServlet")
public class UserProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");

        if ("update".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");

            boolean success = UserDBUtil.updateUser(id, name, email, phone);
            if (success) {
                // Update session with new user details
                user.setName(name);
                user.setEmail(email);
                user.setPhone(phone);
                session.setAttribute("user", user);
                response.sendRedirect("profile.jsp?success=Profile updated successfully");
            } else {
                request.setAttribute("errorMessage", "Update failed. Email might already be in use.");
                request.getRequestDispatcher("profile.jsp").forward(request, response);
            }

        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            boolean success = UserDBUtil.deleteUser(id);
            if (success) {
                session.invalidate(); // Clear session
                response.sendRedirect("login.jsp?success=Account deleted successfully");
            } else {
                request.setAttribute("errorMessage", "Failed to delete account.");
                request.getRequestDispatcher("profile.jsp").forward(request, response);
            }
        }
    }
}