package food;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import adminLogin.DBconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
                 maxFileSize = 1024 * 1024 * 10,       // 10MB
                 maxRequestSize = 1024 * 1024 * 50)    // 50MB
public class FoodInsertServlet extends HttpServlet {

    private static final String IMAGE_UPLOAD_DIR = "images/food";  // inside WebContent

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        double price = Double.parseDouble(priceStr);

        Part filePart = request.getPart("image");
        String fileName = extractFileName(filePart);

        // Get the path to the images/food directory relative to the web application
        String uploadPath = getServletContext().getRealPath("") + File.separator + IMAGE_UPLOAD_DIR;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();  // Create the directory if it doesn't exist
        }

        // Ensure the file name does not include the absolute path
        String filePath = uploadPath + File.separator + fileName;
        filePart.write(filePath);  // Write the file to the server

        // Relative path to the image (for storing in the database)
        String imagePath = IMAGE_UPLOAD_DIR + "/" + fileName;

        try {
            Connection con = DBconnect.getConnection();
            String sql = "INSERT INTO food_items (name, description, price, image) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setString(4, imagePath);  // Save relative path in database
            stmt.executeUpdate();

            response.sendRedirect("foodItems.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Failed to insert food item.");
        }
    }

    private String extractFileName(Part part) {
        // Extract the file name from the content-disposition header
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                // Get the actual file name (without the full path)
                return content.substring(content.indexOf("=") + 2, content.length() - 1).replaceAll("^.*[\\\\/]", "");
            }
        }
        return "default.jpg";  // Default image if none is uploaded
    }
}
