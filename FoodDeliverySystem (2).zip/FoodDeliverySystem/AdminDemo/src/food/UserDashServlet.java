package food;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import adminLogin.DBconnect;

@WebServlet("/userDash")
public class UserDashServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if user is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            System.out.println("User not logged in, redirecting to login.jsp");
            response.sendRedirect("login.jsp");
            return;
        }

        // Prepare the list to hold food items
        List<FoodItem> foodList = new ArrayList<>();
        try {
            // Establish DB connection
            Connection con = DBconnect.getConnection();
            if (con == null) {
                System.out.println("Database connection is null");
                request.setAttribute("error", "Database connection failed. Please try again later.");
            } else {
                System.out.println("Database connection established");
                // SQL query to fetch all food items
                String query = "SELECT * FROM food_items";
                PreparedStatement stmt = con.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                // Process the result set
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String name = rs.getString("name");
                    String description = rs.getString("description");
                    double price = rs.getDouble("price");
                    String image = rs.getString("image");
                    FoodItem foodItem = new FoodItem(id, name, description, price, image);
                    foodList.add(foodItem);
                    System.out.println("Added food item: " + name + ", Price: " + price);
                }

                // Close resources
                rs.close();
                stmt.close();
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQLException occurred: " + e.getMessage());
            request.setAttribute("error", "Failed to load food items: " + e.getMessage());
        }

        // Log the size of the food list
        System.out.println("Number of food items fetched: " + foodList.size());

        // Set the foodList as a request attribute
        request.setAttribute("foodList", foodList);

        // Forward to userDash.jsp
        System.out.println("Forwarding to /WEB-INF/views/userDash.jsp");
        request.getRequestDispatcher("/WEB-INF/views/userDash.jsp").forward(request, response);
    }
}