package food;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import adminLogin.DBconnect;
import java.util.*;

public class FoodItemsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set content type for the response
        response.setContentType("text/html");
        
        // Prepare the list to hold food items
        List<FoodItem> foodList = new ArrayList<>();
        
        try {
            // Establish DB connection
            Connection con = DBconnect.getConnection();
            
            // SQL query to fetch all food items
            String query = "SELECT * FROM food_items";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            // Process the result set and store food items in the list
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                String image = rs.getString("image");

                FoodItem foodItem = new FoodItem(id, name, description, price, image);
                foodList.add(foodItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Log the size of the food list to confirm data retrieval
        System.out.println("Number of food items: " + foodList.size());

        // Set the foodList as an attribute to be accessed in the JSP
        request.setAttribute("foodList", foodList);
        
        // Forward the request to the JSP page
        RequestDispatcher dispatcher = request.getRequestDispatcher("foodItems.jsp");
        dispatcher.forward(request, response);
    }
}
