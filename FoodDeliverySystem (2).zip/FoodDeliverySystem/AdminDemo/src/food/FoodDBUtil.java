package food;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class FoodDBUtil {

    public static boolean deleteFoodItem(int id) {
        boolean isSuccess = false;
        String sql = "DELETE FROM food_items WHERE id = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            isSuccess = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }

    public static boolean updateFoodItem(int id, String name, double price, String image) {
        boolean isSuccess = false;
        String sql = "UPDATE food_items SET name = ?, price = ?, image = ? WHERE id = ?";

        try (Connection con = DBconnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setString(3, image);
            ps.setInt(4, id);
            isSuccess = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSuccess;
    }
}

