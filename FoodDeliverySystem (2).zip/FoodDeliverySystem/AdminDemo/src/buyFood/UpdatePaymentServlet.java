package buyFood;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import UserLogin.User;

public class UpdatePaymentServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = user.getId();
        int paymentId = Integer.parseInt(request.getParameter("paymentId"));

        try {
            Payment payment = PaymentDBUtil.getPaymentByIdAndUserId(paymentId, userId);

            if (payment != null) {
                request.setAttribute("payment", payment);
                request.getRequestDispatcher("paymentUpdate.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Payment not found for update.");
                request.getRequestDispatcher("payment.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error fetching payment details: " + e.getMessage());
            request.getRequestDispatcher("payment.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int paymentId = Integer.parseInt(request.getParameter("paymentId"));
        String cardNumber = request.getParameter("cardNumber");
        String cardHolder = request.getParameter("cardHolder");
        String expiryDate = request.getParameter("expiryDate");
        String cvv = request.getParameter("cvv");

        boolean success = PaymentDBUtil.updatePayment(paymentId, cardNumber, cardHolder, expiryDate, cvv);

        if (success) {
            response.sendRedirect("PaymentServlet");
        } else {
            request.setAttribute("error", "Payment update failed.");
            request.getRequestDispatcher("paymentUpdate.jsp").forward(request, response);
        }
    }
}
