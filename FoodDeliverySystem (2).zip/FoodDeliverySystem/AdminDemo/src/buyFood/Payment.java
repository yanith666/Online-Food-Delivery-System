package buyFood;

public class Payment {
    private int id;
    private int userId;
    private String cardNumber;
    private String cardHolder;
    private String expiryDate;
    private String cvv;
    private double amount;
    private String paymentDate;

    public Payment(int id, int userId, String cardNumber, String cardHolder, String expiryDate, String cvv, double amount, String paymentDate) {
        this.id = id;
        this.userId = userId;
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    // Getters
    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getCardNumber() { return cardNumber; }
    public String getCardHolder() { return cardHolder; }
    public String getExpiryDate() { return expiryDate; }
    public String getCvv() { return cvv; }
    public double getAmount() { return amount; }
    public String getPaymentDate() { return paymentDate; }
}