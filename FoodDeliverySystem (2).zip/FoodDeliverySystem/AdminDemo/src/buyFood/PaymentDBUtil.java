package buyFood;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PaymentDBUtil {
	
	public static Payment getPaymentByIdAndUserId(int paymentId, int userId) throws SQLException {
	    Payment payment = null;
	    Connection conn = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;

	    try {
	        conn = DBconnect.getConnection();
	        String sql = "SELECT * FROM payments WHERE id = ? AND user_id = ?";
	        stmt = conn.prepareStatement(sql);
	        stmt.setInt(1, paymentId);
	        stmt.setInt(2, userId);
	        rs = stmt.executeQuery();

	        if (rs.next()) {
	            payment = new Payment(
	                rs.getInt("id"),
	                rs.getInt("user_id"),
	                rs.getString("card_number"),
	                rs.getString("card_holder"),
	                rs.getString("expiry_date"),
	                rs.getString("cvv"),
	                rs.getDouble("amount"),
	                rs.getString("payment_date")
	            );
	        }
	    } finally {
	        if (rs != null) rs.close();
	        if (stmt != null) stmt.close();
	        if (conn != null) conn.close();
	    }

	    return payment;
	}


	public static boolean updatePayment(int paymentId, String card_number, String card_holder, String expiry_date, String cvv) {
	    boolean isSuccess = false;

	    Connection conn = null;
	    PreparedStatement stmt = null;

	    try {
	        conn = DBconnect.getConnection(); // use your existing DB connection method

	        String sql = "UPDATE payments SET card_number = ?, card_holder = ?, expiry_date = ?, cvv = ? WHERE id = ?";
	        stmt = conn.prepareStatement(sql);
	        stmt.setString(1, card_number);
	        stmt.setString(2, card_holder);
	        stmt.setString(3, expiry_date);
	        stmt.setString(4, cvv);
	        stmt.setInt(5, paymentId);

	        int rows = stmt.executeUpdate();
	        isSuccess = rows > 0;

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (stmt != null) stmt.close();
	            if (conn != null) conn.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    return isSuccess;
	}
	
}
