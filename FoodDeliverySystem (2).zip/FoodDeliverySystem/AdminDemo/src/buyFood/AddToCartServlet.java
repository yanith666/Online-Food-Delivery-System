package buyFood;

import food.FoodItem;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Get the food item ID from the form
        int foodId = Integer.parseInt(request.getParameter("foodId"));
        
        // Fetch the food item directly from the database
        FoodItem selectedItem = null;
        try (Connection con = DBconnect.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection is null");
            }
            String query = "SELECT * FROM food_items WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, foodId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                String image = rs.getString("image");
                selectedItem = new FoodItem(id, name, description, price, image);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Optionally, set an error message and forward to an error page
            request.setAttribute("error", "Failed to fetch food item: " + e.getMessage());
            request.getRequestDispatcher("userDash.jsp").forward(request, response);
            return;
        }

        // Add the item to the cart if found
        if (selectedItem != null) {
            HttpSession session = request.getSession();
            List<FoodItem> cart = (List<FoodItem>) session.getAttribute("cart");
            if (cart == null) {
                cart = new ArrayList<>();
            }
            cart.add(selectedItem);
            session.setAttribute("cart", cart);
        } else {
            // Handle case where food item is not found
            request.setAttribute("error", "Food item with ID " + foodId + " not found.");
            request.getRequestDispatcher("userDash.jsp").forward(request, response);
            return;
        }

        // Redirect back to UserFoodItemsServlet to refresh the page
        response.sendRedirect("UserFoodItemsServlet");
    }
}