package buyFood;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import UserLogin.User;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Prevent browser caching
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = user.getId();
        List<Payment> payments = new ArrayList<>();

        // Fetch payments for the user
        try (Connection con = DBconnect.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection is null");
            }
            String query = "SELECT * FROM payments WHERE user_id = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, userId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Payment payment = new Payment(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getString("card_number"),
                            rs.getString("card_holder"),
                            rs.getString("expiry_date"),
                            rs.getString("cvv"),
                            rs.getDouble("amount"),
                            rs.getString("payment_date")
                        );
                        payments.add(payment);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Failed to fetch payments: " + e.getMessage());
        }

        // Debug log to verify payments
        System.out.println("doGet: Payments size for user " + userId + ": " + payments.size());

        // Calculate cart total for payment (unchanged)
        double cartTotal = 0.0;
        List<food.FoodItem> cart = (List<food.FoodItem>) session.getAttribute("cart");
        if (cart != null) {
            for (food.FoodItem item : cart) {
                cartTotal += item.getPrice();
            }
        }

        // Check if there's a preserved cart total from a previous payment (unchanged)
        Double preservedCartTotal = (Double) session.getAttribute("preservedCartTotal");
        if (preservedCartTotal != null) {
            cartTotal = preservedCartTotal;
            session.removeAttribute("preservedCartTotal");
        }

        request.setAttribute("cartTotal", cartTotal);
        request.setAttribute("payments", payments);
        request.getRequestDispatcher("orders.jsp").forward(request, response); // Changed to orders.jsp
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Prevent browser caching
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int userId = user.getId();
        String action = request.getParameter("action");
        List<Payment> payments = new ArrayList<>();
        boolean operationSuccessful = false;
        String successMessage = null;

        try (Connection con = DBconnect.getConnection()) {
            if (con == null) {
                throw new SQLException("Database connection is null");
            }

            if ("create".equals(action)) {
                // Calculate cart total before clearing the cart (unchanged)
                double cartTotal = 0.0;
                List<food.FoodItem> cart = (List<food.FoodItem>) session.getAttribute("cart");
                if (cart != null) {
                    for (food.FoodItem item : cart) {
                        cartTotal += item.getPrice();
                    }
                }

                // Create a new payment (unchanged)
                String cardNumber = request.getParameter("cardNumber");
                String cardHolder = request.getParameter("cardHolder");
                String expiryDate = request.getParameter("expiryDate");
                String cvv = request.getParameter("cvv");
                double amount = Double.parseDouble(request.getParameter("amount"));

                String query = "INSERT INTO payments (user_id, card_number, card_holder, expiry_date, cvv, amount, payment_date) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                try (PreparedStatement stmt = con.prepareStatement(query)) {
                    stmt.setInt(1, userId);
                    stmt.setString(2, cardNumber);
                    stmt.setString(3, cardHolder);
                    stmt.setString(4, expiryDate);
                    stmt.setString(5, cvv);
                    stmt.setDouble(6, amount);
                    stmt.executeUpdate();
                }

                // Preserve the cart total in the session (unchanged)
                session.setAttribute("preservedCartTotal", cartTotal);

                // Clear the cart after successful payment (unchanged)
                session.setAttribute("cart", null);

                successMessage = "Payment added successfully";
                operationSuccessful = true;
            } else if ("delete".equals(action)) {
                // Delete a payment (unchanged)
                int paymentId = Integer.parseInt(request.getParameter("paymentId"));
                String query = "DELETE FROM payments WHERE id = ? AND user_id = ?";
                try (PreparedStatement stmt = con.prepareStatement(query)) {
                    stmt.setInt(1, paymentId);
                    stmt.setInt(2, userId);
                    int rowsAffected = stmt.executeUpdate();
                    if (rowsAffected > 0) {
                        successMessage = "Payment deleted successfully";
                        operationSuccessful = true;
                    } else {
                        request.setAttribute("error", "Payment not found or you don't have permission to delete it");
                    }
                }
            }

            // Fetch the updated payment list (unchanged)
            String query = "SELECT * FROM payments WHERE user_id = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, userId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Payment payment = new Payment(
                            rs.getInt("id"),
                            rs.getInt("user_id"),
                            rs.getString("card_number"),
                            rs.getString("card_holder"),
                            rs.getString("expiry_date"),
                            rs.getString("cvv"),
                            rs.getDouble("amount"),
                            rs.getString("payment_date")
                        );
                        payments.add(payment);
                    }
                }
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("error", "Payment operation failed: " + e.getMessage());
        }

        // Debug log to verify payments
        System.out.println("doPost: Action = " + action + ", Payments size for user " + userId + ": " + payments.size());

        // Set attributes for rendering
        request.setAttribute("payments", payments);
        if (operationSuccessful) {
            request.setAttribute("success", successMessage);
        }

        // Forward to appropriate JSP based on action
        if ("create".equals(action)) {
            request.getRequestDispatcher("payment.jsp").forward(request, response); // Keep payment.jsp for create
        } else {
            request.getRequestDispatcher("orders.jsp").forward(request, response); // Use orders.jsp for delete and errors
        }
    }
}