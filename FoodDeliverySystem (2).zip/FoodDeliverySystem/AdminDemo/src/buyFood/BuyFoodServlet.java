package buyFood;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BuyFoodServlet")
public class BuyFoodServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set content type and response encoding
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // Establish DB connection
        try (Connection con = DBconnect.getConnection()) {
            if (con != null) {
                // Prepare the SQL query to fetch food items
                String sql = "SELECT id, name, price FROM food_items"; // Adjust the query as per your DB schema
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();

                // Set the ResultSet as a request attribute
                request.setAttribute("foodItems", rs);
                request.getRequestDispatcher("buy_food.jsp").forward(request, response);
            } else {
                PrintWriter out = response.getWriter();
                out.println("Database connection error.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            out.println("Error while fetching food items from the database.");
        }
    }
}
